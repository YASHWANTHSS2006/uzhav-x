package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AgriRepository
import com.example.data.FirestoreAgriService
import com.example.data.MandiPriceService
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class UzhavScreen {
    HOME,
    CROP_RECOMMENDATION,
    MANDI_PRICES,
    STORES_MAP,
    SCHEMES_2026,
    EQUIPMENT_MARKET,
    WEATHER_ADVISORY,
    PLANT_SCANNER,
    COMMUNITY_FORUM,
    DAILY_NEWS,
    FEEDBACK_REPORTS,
    AI_CHATBOT,
    PROFILE_REGISTRATION,
    LOGIN,
    ADMIN_DASHBOARD
}

enum class StoreSortOption {
    PROXIMITY,
    PRICE_LOW_TO_HIGH,
    RATING;

    fun getDisplayName(lang: AppLanguage): String = when (this) {
        PROXIMITY -> if (lang == AppLanguage.TAMIL) "அருகிலுள்ளவை (தூரம்)" else "Nearest (Proximity)"
        PRICE_LOW_TO_HIGH -> if (lang == AppLanguage.TAMIL) "குறைந்த விலை" else "Lowest Price"
        RATING -> if (lang == AppLanguage.TAMIL) "சிறந்த மதிப்பீடு" else "Top Rated"
    }
}

data class UzhavUiState(
    val language: AppLanguage = AppLanguage.TAMIL, // Default to Tamil as requested
    val currentRole: UserRole = UserRole.FARMER,
    val currentScreen: UzhavScreen = UzhavScreen.HOME,
    val farmerProfile: FarmerProfile = FarmerProfile(),

    // Crop Recommendation
    val recommendationRequest: CropRecommendationRequest = CropRecommendationRequest(),
    val recommendationResult: RecommendationResult? = null,
    val isCalculatingRecommendation: Boolean = false,

    // Mandi Prices
    val mandiPrices: List<MandiPrice> = emptyList(),
    val selectedMandiCategory: String = "All",
    val selectedMandiRegion: String = "All Regions",
    val mandiSearchQuery: String = "",
    val selectedMandiPriceForDetail: MandiPrice? = null,
    val isMandiLoading: Boolean = false,
    val mandiErrorMessage: String? = null,
    val mandiLastFetchedTime: String = "Today 08:30 AM",
    val mandiRegionalSummary: MandiRegionalSummary? = null,
    val mandiGroundedSearchResult: MandiSearchGroundingResult? = null,
    val isMandiSearchGrounding: Boolean = false,
    val mandiSearchGroundingError: String? = null,

    // Agri Stores & Inventory (Mutable for Admin)
    val stores: List<AgriStore> = AgriRepository.initialStores,
    val selectedStoreCategory: FertilizerType? = null,
    val selectedFertilizerNameFilter: String? = null,
    val maxProximityKm: Float? = null, // null = All TN, or 15f, 30f, 50f, 100f
    val storeSortOption: StoreSortOption = StoreSortOption.PROXIMITY,
    val selectedStoreForMap: AgriStore? = AgriRepository.initialStores.firstOrNull(),
    val storeSearchQuery: String = "",
    val selectedDistrictFilter: String = "All Districts",

    // 2026 Government Schemes
    val schemes: List<GovtScheme> = AgriRepository.sampleSchemes,
    val selectedSchemeCategory: SchemeCategory = SchemeCategory.ALL,
    val schemeSearchQuery: String = "",
    val selectedSchemeForDetail: GovtScheme? = null,

    // Daily News
    val newsList: List<AgriNews> = AgriRepository.sampleNews,
    val selectedNewsCategory: NewsCategory = NewsCategory.ALL,
    val selectedNewsForDetail: AgriNews? = null,

    // Equipments
    val equipments: List<AgriEquipment> = AgriRepository.sampleEquipments,
    val selectedEquipmentCategory: EquipmentCategory? = null,

    // Weather
    val weatherReport: AgriWeatherReport = AgriRepository.sampleWeatherReport,

    // Plant Doctor Scanner
    val currentDiagnosis: PlantDiseaseDiagnosis? = null,
    val isScanning: Boolean = false,
    val scannedImageBitmap: android.graphics.Bitmap? = null,
    val scanStatusMessage: String? = null,

    // Community Forum
    val forumPosts: List<ForumPost> = AgriRepository.sampleForumPosts,
    val selectedCropFilterForum: String = "All",

    // Feedback & Grievances (Admin manages)
    val feedbackReports: List<FeedbackReport> = AgriRepository.sampleFeedbackReports.toList(),

    // AI Chatbot
    val chatMessages: List<ChatMessage> = listOf(
        ChatMessage(
            id = "init",
            text = "வணக்கம்! நான் உழவன் AI - உங்கள் டிஜிட்டல் வேளாண் உதவியாளர். பயிர் பரிந்துரை, தினசரி மண்டி விலை, உரக்கடை விபரம், 2026 மானியங்கள் அல்லது பயிர் நோய் தீர்வு பற்றி தமிழில் அல்லது ஆங்கிலத்தில் கேளுங்கள்!\n\nHello! I am Uzhav X AI - your smart farming guide. Ask me anything in Tamil or English!",
            isUser = false,
            timestamp = "Just now",
            suggestedFollowups = listOf(
                "சம்பா நெல் இலைக்கருகல் நோய் மருந்து என்ன?",
                "சொட்டு நீர் 100% மானியம் பெறுவது எப்படி?",
                "இன்றைய ஈரோடு மஞ்சள் விலை நிலவரம்",
                "இயற்கை பஞ்சகாவ்யா தயாரிக்கும் முறை"
            )
        )
    ),
    val isAiThinking: Boolean = false,
    val currentAiInputText: String = "",

    // Admin state dialogs & notices
    val adminNoticeMessage: String? = null
)

class UzhavViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(UzhavUiState())
    val uiState: StateFlow<UzhavUiState> = _uiState.asStateFlow()

    private val firestoreService = FirestoreAgriService()
    val mandiPriceService = MandiPriceService()
    val plantScannerService = com.example.data.PlantDiseaseScannerService()
    val geminiCropAdvisorService = com.example.data.GeminiCropAdvisorService()

    init {
        // Run initial recommendation with default profile values
        calculateCropRecommendation()
        initFirestoreSync()
        fetchDailyMandiPrices(forceRefresh = false)
    }

    private fun initFirestoreSync() {
        try {
            firestoreService.listenToForumPosts(
                onUpdate = { cloudPosts ->
                    if (cloudPosts.isNotEmpty()) {
                        _uiState.update { current ->
                            val existingIds = cloudPosts.map { it.id }.toSet()
                            val localUnique = current.forumPosts.filter { it.id !in existingIds }
                            current.copy(forumPosts = cloudPosts + localUnique)
                        }
                    }
                },
                onError = { /* fallback gracefully to repository sample data */ }
            )
            firestoreService.listenToMandiPrices(
                onUpdate = { cloudPrices ->
                    if (cloudPrices.isNotEmpty()) {
                        _uiState.update { it.copy(mandiPrices = cloudPrices) }
                    }
                },
                onError = { /* fallback gracefully */ }
            )
        } catch (_: Exception) {}
    }

    // --- Language & Role Management ---

    fun toggleLanguage() {
        _uiState.update { current ->
            val nextLang = if (current.language == AppLanguage.TAMIL) AppLanguage.ENGLISH else AppLanguage.TAMIL
            current.copy(language = nextLang)
        }
    }

    fun setLanguage(lang: AppLanguage) {
        _uiState.update { it.copy(language = lang) }
    }

    fun toggleUserRole() {
        _uiState.update { current ->
            val nextRole = if (current.currentRole == UserRole.FARMER) UserRole.ADMIN else UserRole.FARMER
            val notice = if (nextRole == UserRole.ADMIN) {
                if (current.language == AppLanguage.TAMIL) "நிர்வாகி அணுகல் (அட்மின் மோடு) செயல்படுத்தப்பட்டது. நீங்கள் கடைகளின் இருப்பு, உர விலைகள் மற்றும் விவசாயிகளின் புகார்களை நிர்வகிக்கலாம்."
                else "Admin Mode Enabled. You can update store inventory, fertilizer prices, and resolve farmer grievances."
            } else {
                if (current.language == AppLanguage.TAMIL) "விவசாயி (பயனர்) முறைக்கு மாற்றப்பட்டது."
                else "Switched to Farmer (User) Mode."
            }
            current.copy(currentRole = nextRole, adminNoticeMessage = notice)
        }
    }

    fun dismissAdminNotice() {
        _uiState.update { it.copy(adminNoticeMessage = null) }
    }

    fun navigateTo(screen: UzhavScreen) {
        _uiState.update { it.copy(currentScreen = screen) }
    }

    // --- Profile Management ---

    fun updateProfile(profile: FarmerProfile) {
        _uiState.update { current ->
            current.copy(
                farmerProfile = profile,
                recommendationRequest = current.recommendationRequest.copy(
                    district = profile.district,
                    taluka = profile.taluka,
                    village = profile.village,
                    soilType = profile.soilType,
                    landSizeAcres = profile.landSizeAcres
                )
            )
        }
        calculateCropRecommendation()
        recalculateStoreDistancesForDistrict(profile.district)
        viewModelScope.launch {
            try {
                firestoreService.saveFarmerProfile(profile)
            } catch (_: Exception) {}
        }
    }

    // --- AI-Powered Crop Recommendation ---

    fun updateRecommendationInput(
        district: String? = null,
        taluka: String? = null,
        village: String? = null,
        soilType: String? = null,
        season: String? = null,
        waterSource: String? = null,
        landSize: Double? = null
    ) {
        _uiState.update { current ->
            val updated = current.recommendationRequest.copy(
                district = district ?: current.recommendationRequest.district,
                taluka = taluka ?: current.recommendationRequest.taluka,
                village = village ?: current.recommendationRequest.village,
                soilType = soilType ?: current.recommendationRequest.soilType,
                season = season ?: current.recommendationRequest.season,
                waterSource = waterSource ?: current.recommendationRequest.waterSource,
                landSizeAcres = landSize ?: current.recommendationRequest.landSizeAcres
            )
            current.copy(recommendationRequest = updated)
        }
    }

    fun calculateCropRecommendation() {
        viewModelScope.launch {
            _uiState.update { it.copy(isCalculatingRecommendation = true) }
            val req = _uiState.value.recommendationRequest
            val lang = _uiState.value.language
            val result = geminiCropAdvisorService.getRecommendations(req, lang)
            _uiState.update {
                it.copy(
                    recommendationResult = result,
                    isCalculatingRecommendation = false
                )
            }
        }
    }

    // --- Mandi Prices & Regional Market Trends ---

    fun fetchDailyMandiPrices(forceRefresh: Boolean = false) {
        viewModelScope.launch {
            _uiState.update { it.copy(isMandiLoading = true, mandiErrorMessage = null) }
            val result = mandiPriceService.fetchDailyMarketPrices(forceRefresh = forceRefresh)
            result.onSuccess { prices ->
                val summary = mandiPriceService.computeRegionalSummary(prices)
                _uiState.update { current ->
                    val selectedDetail = if (current.selectedMandiPriceForDetail != null) {
                        prices.find { it.id == current.selectedMandiPriceForDetail.id } ?: prices.firstOrNull()
                    } else {
                        prices.firstOrNull()
                    }
                    current.copy(
                        mandiPrices = prices,
                        selectedMandiPriceForDetail = selectedDetail,
                        mandiRegionalSummary = summary,
                        isMandiLoading = false,
                        mandiErrorMessage = null,
                        mandiLastFetchedTime = prices.firstOrNull()?.lastUpdated ?: current.mandiLastFetchedTime
                    )
                }
            }.onFailure { error ->
                _uiState.update {
                    it.copy(
                        isMandiLoading = false,
                        mandiErrorMessage = error.localizedMessage ?: "Failed to fetch mandi prices"
                    )
                }
            }
        }
    }

    fun refreshMandiPrices() {
        fetchDailyMandiPrices(forceRefresh = true)
    }

    fun setMandiRegion(region: String) {
        _uiState.update { it.copy(selectedMandiRegion = region) }
    }

    fun setMandiCategory(category: String) {
        _uiState.update { it.copy(selectedMandiCategory = category) }
    }

    fun setMandiSearchQuery(query: String) {
        _uiState.update { it.copy(mandiSearchQuery = query) }
    }

    fun selectMandiPriceForDetail(item: MandiPrice) {
        _uiState.update { it.copy(selectedMandiPriceForDetail = item) }
    }

    fun searchLiveMandiWithGoogle(queryOverride: String? = null) {
        val query = queryOverride ?: _uiState.value.mandiSearchQuery.ifBlank { "Tamil Nadu mandi crop prices today" }
        viewModelScope.launch {
            _uiState.update { it.copy(isMandiSearchGrounding = true, mandiSearchGroundingError = null) }
            try {
                val result = mandiPriceService.searchLiveTNMarketPricesWithGoogle(query, _uiState.value.language)
                _uiState.update {
                    it.copy(
                        isMandiSearchGrounding = false,
                        mandiGroundedSearchResult = result,
                        mandiSearchGroundingError = null
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isMandiSearchGrounding = false,
                        mandiSearchGroundingError = e.localizedMessage ?: "Grounded search failed"
                    )
                }
            }
        }
    }

    fun dismissMandiGroundedSearch() {
        _uiState.update { it.copy(mandiGroundedSearchResult = null, mandiSearchGroundingError = null) }
    }

    // --- Stores & Fertilizer Price Comparison ---

    fun setStoreCategory(category: FertilizerType?) {
        _uiState.update { it.copy(selectedStoreCategory = category) }
    }

    fun setSelectedFertilizerNameFilter(name: String?) {
        _uiState.update { it.copy(selectedFertilizerNameFilter = name) }
    }

    fun setStoreProximityFilter(maxKm: Float?) {
        _uiState.update { it.copy(maxProximityKm = maxKm) }
    }

    fun setStoreSortOption(sort: StoreSortOption) {
        _uiState.update { it.copy(storeSortOption = sort) }
    }

    fun setStoreDistrictFilter(district: String) {
        _uiState.update { it.copy(selectedDistrictFilter = district) }
        if (district != "All Districts") {
            recalculateStoreDistancesForDistrict(district)
        }
    }

    fun setStoreSearchQuery(query: String) {
        _uiState.update { it.copy(storeSearchQuery = query) }
    }

    fun selectStoreForMap(store: AgriStore) {
        _uiState.update { it.copy(selectedStoreForMap = store) }
    }

    fun recalculateStoreDistancesForDistrict(district: String) {
        val (farmerLat, farmerLon) = AgriRepository.getDistrictCoordinates(district)
        _uiState.update { current ->
            val updated = current.stores.map { store ->
                val dist = AgriRepository.calculateDistanceKm(farmerLat, farmerLon, store.latitude, store.longitude)
                store.copy(distanceKm = dist)
            }
            current.copy(
                stores = updated,
                selectedStoreForMap = updated.find { it.id == current.selectedStoreForMap?.id } ?: updated.firstOrNull()
            )
        }
    }

    // --- Admin Operations: Update Store Inventory & Fertilizer Prices ---

    fun adminUpdateProductStockAndPrice(
        storeId: String,
        productId: String,
        newStandardPrice: Int,
        newSubsidizedPrice: Int?,
        inStock: Boolean
    ) {
        _uiState.update { current ->
            val updatedStores = current.stores.map { store ->
                if (store.id == storeId) {
                    val updatedProducts = store.products.map { prod ->
                        if (prod.id == productId) {
                            prod.copy(
                                standardPrice = newStandardPrice,
                                subsidizedPrice = newSubsidizedPrice,
                                inStock = inStock
                            )
                        } else prod
                    }
                    store.copy(products = updatedProducts)
                } else store
            }
            val msg = if (current.language == AppLanguage.TAMIL) "உரத்தின் விலை & இருப்பு வெற்றிகரமாக புதுப்பிக்கப்பட்டது!" else "Product price and stock updated successfully!"
            current.copy(
                stores = updatedStores,
                selectedStoreForMap = updatedStores.find { it.id == current.selectedStoreForMap?.id } ?: updatedStores.firstOrNull(),
                adminNoticeMessage = msg
            )
        }
    }

    fun adminAddNewProductToStore(
        storeId: String,
        productName: String,
        tamilName: String,
        category: FertilizerType,
        brand: String,
        bagSize: String,
        standardPrice: Int,
        subsidizedPrice: Int?
    ) {
        val newProd = FertilizerProduct(
            id = "p_custom_${System.currentTimeMillis()}",
            name = productName,
            tamilName = tamilName,
            category = category,
            brand = brand,
            bagSize = bagSize,
            standardPrice = standardPrice,
            subsidizedPrice = subsidizedPrice,
            inStock = true,
            composition = "Authorized agricultural input formula",
            usageNotes = "Apply as per recommended field dosage"
        )
        _uiState.update { current ->
            val updatedStores = current.stores.map { store ->
                if (store.id == storeId) {
                    store.copy(products = store.products + newProd)
                } else store
            }
            val msg = if (current.language == AppLanguage.TAMIL) "புதிய உரம் / விதை சேர்க்கப்பட்டது!" else "New fertilizer product added to shop!"
            current.copy(
                stores = updatedStores,
                selectedStoreForMap = updatedStores.find { it.id == current.selectedStoreForMap?.id } ?: updatedStores.firstOrNull(),
                adminNoticeMessage = msg
            )
        }
    }

    // --- 2026 Schemes ---

    fun setSchemeCategory(category: SchemeCategory) {
        _uiState.update { it.copy(selectedSchemeCategory = category) }
    }

    fun setSchemeSearchQuery(query: String) {
        _uiState.update { it.copy(schemeSearchQuery = query) }
    }

    fun selectSchemeForDetail(scheme: GovtScheme?) {
        _uiState.update { it.copy(selectedSchemeForDetail = scheme) }
    }

    // --- Daily News ---

    fun setNewsCategory(category: NewsCategory) {
        _uiState.update { it.copy(selectedNewsCategory = category) }
    }

    fun selectNewsForDetail(news: AgriNews?) {
        _uiState.update { it.copy(selectedNewsForDetail = news) }
    }

    // --- Equipments Marketplace ---

    fun setEquipmentCategory(category: EquipmentCategory?) {
        _uiState.update { it.copy(selectedEquipmentCategory = category) }
    }

    // --- Plant Disease Scanner ---
    fun scanLeafSample(diagnosisIndex: Int = 0) {
        viewModelScope.launch {
            val statusMsg = if (_uiState.value.language == AppLanguage.TAMIL)
                "Gemini AI மாதிரி இலையை ஆய்வு செய்கிறது..."
            else
                "Gemini AI analyzing crop leaf pattern..."
            _uiState.update { it.copy(isScanning = true, scanStatusMessage = statusMsg) }
            kotlinx.coroutines.delay(1000)
            val diagnosis = AgriRepository.sampleDiseases.getOrNull(diagnosisIndex)
                ?: AgriRepository.sampleDiseases.first()
            _uiState.update {
                it.copy(
                    isScanning = false,
                    scanStatusMessage = null,
                    currentDiagnosis = diagnosis,
                    scannedImageBitmap = null
                )
            }
        }
    }

    fun analyzeCustomLeaf(bitmap: android.graphics.Bitmap) {
        viewModelScope.launch {
            val statusMsg = if (_uiState.value.language == AppLanguage.TAMIL)
                "Gemini 3.8 Flash AI இலை நோயை கண்டறிகிறது..."
            else
                "Gemini 3.8 Flash AI scanning leaf pathology..."
            _uiState.update {
                it.copy(
                    isScanning = true,
                    scannedImageBitmap = bitmap,
                    scanStatusMessage = statusMsg
                )
            }
            try {
                val diagnosis = plantScannerService.analyzeLeafImage(bitmap, _uiState.value.language)
                _uiState.update {
                    it.copy(
                        isScanning = false,
                        scanStatusMessage = null,
                        currentDiagnosis = diagnosis,
                        scannedImageBitmap = bitmap
                    )
                }
            } catch (e: Exception) {
                val fallback = AgriRepository.sampleDiseases.first()
                _uiState.update {
                    it.copy(
                        isScanning = false,
                        scanStatusMessage = null,
                        currentDiagnosis = fallback,
                        scannedImageBitmap = bitmap
                    )
                }
            }
        }
    }

    fun analyzeLeafFromUri(context: android.content.Context, uri: android.net.Uri) {
        viewModelScope.launch {
            val bitmap = plantScannerService.decodeBitmapFromUri(context, uri)
            if (bitmap != null) {
                analyzeCustomLeaf(bitmap)
            }
        }
    }

    fun clearDiagnosis() {
        _uiState.update { it.copy(currentDiagnosis = null, scannedImageBitmap = null, scanStatusMessage = null) }
    }

    // --- Community Forum ---

    fun toggleUpvote(postId: String) {
        _uiState.update { current ->
            val updated = current.forumPosts.map { post ->
                if (post.id == postId) {
                    val newUpvoted = !post.hasUserUpvoted
                    val newCount = if (newUpvoted) post.upvotes + 1 else (post.upvotes - 1).coerceAtLeast(0)
                    post.copy(
                        upvotes = newCount,
                        hasUserUpvoted = newUpvoted,
                        likesCount = newCount,
                        hasLiked = newUpvoted
                    )
                } else post
            }
            current.copy(forumPosts = updated)
        }
    }

    fun toggleCommentLike(postId: String, commentId: String) {
        _uiState.update { current ->
            val updated = current.forumPosts.map { post ->
                if (post.id == postId) {
                    val updatedComments = post.comments.map { comment ->
                        if (comment.id == commentId) {
                            val nextLiked = !comment.hasLiked
                            val nextCount = if (nextLiked) comment.upvotes + 1 else (comment.upvotes - 1).coerceAtLeast(0)
                            comment.copy(hasLiked = nextLiked, upvotes = nextCount)
                        } else comment
                    }
                    post.copy(comments = updatedComments)
                } else post
            }
            current.copy(forumPosts = updated)
        }
    }

    fun addCommentToPost(postId: String, commentText: String) {
        if (commentText.isBlank()) return
        val newComment = ForumComment(
            id = "c_${System.currentTimeMillis()}",
            authorName = _uiState.value.farmerProfile.name,
            authorRole = if (_uiState.value.currentRole == UserRole.ADMIN) "Agri Officer / Store Admin" else "Farmer (${_uiState.value.farmerProfile.district})",
            timeAgo = "Just now",
            content = commentText,
            isExpertAnswer = _uiState.value.currentRole == UserRole.ADMIN,
            upvotes = 0,
            hasLiked = false
        )
        _uiState.update { current ->
            val updated = current.forumPosts.map { post ->
                if (post.id == postId) {
                    post.copy(comments = post.comments + newComment)
                } else post
            }
            current.copy(forumPosts = updated)
        }
    }

    fun createNewForumPost(
        title: String,
        body: String,
        cropTag: String,
        postType: ForumPostType = ForumPostType.QUESTION
    ) {
        if (title.isBlank() || body.isBlank()) return
        val newPost = ForumPost(
            id = "f_${System.currentTimeMillis()}",
            authorName = _uiState.value.farmerProfile.name,
            authorDistrict = _uiState.value.farmerProfile.district,
            authorRole = if (_uiState.value.currentRole == UserRole.ADMIN) "Agri Dept Officer" else "Farmer (${_uiState.value.farmerProfile.village})",
            isVerifiedExpert = _uiState.value.currentRole == UserRole.ADMIN,
            timeAgo = "Just now",
            title = title,
            body = body,
            cropTag = cropTag,
            upvotes = 1,
            hasUserUpvoted = true,
            comments = emptyList(),
            postType = postType,
            likesCount = 1,
            hasLiked = true
        )
        _uiState.update { it.copy(forumPosts = listOf(newPost) + it.forumPosts) }
        viewModelScope.launch {
            try {
                firestoreService.addForumPost(newPost)
            } catch (_: Exception) {}
        }
    }

    // --- Feedback & Grievances ---

    fun submitFeedbackReport(category: ReportCategory, description: String) {
        if (description.isBlank()) return
        val report = FeedbackReport(
            id = "rep_${System.currentTimeMillis()}",
            farmerName = _uiState.value.farmerProfile.name,
            district = _uiState.value.farmerProfile.district,
            taluka = _uiState.value.farmerProfile.taluka,
            village = _uiState.value.farmerProfile.village,
            phone = _uiState.value.farmerProfile.contact,
            category = category,
            description = description,
            timestamp = "Today",
            status = ReportStatus.SUBMITTED
        )
        _uiState.update { current ->
            val msg = if (current.language == AppLanguage.TAMIL) "உங்கள் புகார் / கருத்து பதிவு செய்யப்பட்டது. வேளாண் உதவி அலுவலர் விரைவில் பரிசீலிப்பார்!" else "Your report has been submitted to the Agri Extension desk!"
            current.copy(
                feedbackReports = listOf(report) + current.feedbackReports,
                adminNoticeMessage = msg
            )
        }
        viewModelScope.launch {
            try {
                firestoreService.submitGrievance(report)
            } catch (_: Exception) {}
        }
    }

    fun adminUpdateReportStatus(reportId: String, newStatus: ReportStatus) {
        _uiState.update { current ->
            val updated = current.feedbackReports.map {
                if (it.id == reportId) it.copy(status = newStatus) else it
            }
            val msg = if (current.language == AppLanguage.TAMIL) "புகார் நிலை '${newStatus.getDisplayName(current.language)}' என மாற்றப்பட்டது." else "Report status updated to ${newStatus.name}"
            current.copy(feedbackReports = updated, adminNoticeMessage = msg)
        }
    }

    // --- AI Chatbot ---

    fun updateAiInputText(text: String) {
        _uiState.update { it.copy(currentAiInputText = text) }
    }

    fun sendAiMessage(promptText: String? = null) {
        val query = (promptText ?: _uiState.value.currentAiInputText).trim()
        if (query.isBlank()) return

        val userMsg = ChatMessage(
            id = "u_${System.currentTimeMillis()}",
            text = query,
            isUser = true,
            timestamp = "Just now"
        )

        _uiState.update {
            it.copy(
                chatMessages = it.chatMessages + userMsg,
                currentAiInputText = "",
                isAiThinking = true
            )
        }

        viewModelScope.launch {
            kotlinx.coroutines.delay(1000)
            val lang = _uiState.value.language
            val replyText = generateAgriExpertReply(query, lang)
            val aiMsg = ChatMessage(
                id = "ai_${System.currentTimeMillis()}",
                text = replyText,
                isUser = false,
                timestamp = "Just now",
                suggestedFollowups = if (lang == AppLanguage.TAMIL) listOf(
                    "இன்றைய மண்டி விலை என்ன?",
                    "பஞ்சகாவ்யா தயாரிப்பது எப்படி?",
                    "சொட்டு நீர் 100% மானிய தகுதி என்ன?"
                ) else listOf(
                    "Check today's Mandi price",
                    "How to prepare Panchagavya?",
                    "Drip irrigation 100% subsidy rules"
                )
            )
            _uiState.update {
                it.copy(
                    chatMessages = it.chatMessages + aiMsg,
                    isAiThinking = false
                )
            }
        }
    }

    private fun generateAgriExpertReply(query: String, lang: AppLanguage): String {
        val q = query.lowercase()
        return when {
            q.contains("விலை") || q.contains("price") || q.contains("mandi") || q.contains("சந்தை") -> {
                if (lang == AppLanguage.TAMIL) {
                    "🌾 இன்றைய தமிழ்நாடு சந்தை நிலவரம்:\n• நேரடி நெல் கொள்முதல் விலை: ₹2,450/குவிண்டால் (தமிழக அரசு ஊக்கத்தொகையுடன்)\n• ஈரோடு விரலி மஞ்சள்: ₹15,900/குவிண்டால் (உயர் வரத்து)\n• பொள்ளாச்சி இளநீர்: ₹42/காய்\n• ஒட்டன்சத்திரம் நாட்டு தக்காளி: ₹24/கிலோ\n• திண்டுக்கல் சின்ன வெங்காயம்: ₹52/கிலோ\n\nவிரிவான 7 நாள் விலை மாற்ற வரைபடத்தை 'மண்டி விலைகள்' பக்கத்தில் பார்க்கலாம்!"
                } else {
                    "🌾 Today's Tamil Nadu Mandi Highlights:\n• Paddy (Samba): ₹2,450/quintal at Direct Purchase Centres\n• Erode Turmeric (Finger): ₹15,900/quintal (Strong export bidding)\n• Pollachi Tender Coconut: ₹42/nut\n• Oddanchatram Tomato: ₹24/kg\n• Dindigul Shallots: ₹52/kg\n\nVisit the 'Mandi Prices' tab for interactive 7-day trend graphs!"
                }
            }
            q.contains("மானியம்") || q.contains("subsidy") || q.contains("scheme") || q.contains("திட்டம்") || q.contains("கடன்") || q.contains("loan") -> {
                if (lang == AppLanguage.TAMIL) {
                    "🏛️ 2026-27 முக்கிய தமிழக அரசு மானியங்கள்:\n1. சொட்டு நீர் பாசனம்: 5 ஏக்கருக்கு குறைவான சிறு/குறு விவசாயிகளுக்கு 100% முழு மானியம் (ஹெக்டேருக்கு ₹1,35,000 வரை).\n2. சூரிய மின்சார பம்பு செட் (PM-KUSUM): 70% அரசு மானியத்தில் 5-10 HP மோட்டார்.\n3. தொடக்க கூட்டுறவு பயிர் கடன் (KCC): 12 மாதத்திற்குள் திருப்பி செலுத்தினால் 0% முற்றிலும் வட்டி இல்லா கடன் (ஏக்கருக்கு ₹52,000 வரை).\n4. கிசான் ட்ரோன் & டிராக்டர்: 50% முதல் 80% வரை SMAM மானியம்.\n\nவிண்ணப்பிக்க தேவையான ஆவணங்கள் மற்றும் வழிகாட்டுதலுக்கு 'அரசு திட்டங்கள்' பக்கத்தை பார்க்கவும்!"
                } else {
                    "🏛️ 2026-27 Key Tamil Nadu Agriculture Schemes:\n1. Micro Irrigation (Drip): 100% full subsidy for Small & Marginal farmers (< 5 acres) up to ₹1,35,000/ha.\n2. Solar Pumps (PM-KUSUM): 70% capital subsidy on 5HP to 10HP stand-alone pumps.\n3. Kisan Credit Card (KCC): 0% zero-interest crop loans up to ₹3,00,000 through PACCS on prompt repayment.\n4. Farm Mechanization (SMAM): 50% subsidy on tractors and 80% on Kisan spraying drones.\n\nCheck the 'Govt Schemes' tab for application steps & document checklists!"
                }
            }
            q.contains("நோய்") || q.contains("மருந்து") || q.contains("disease") || q.contains("blast") || q.contains("கருகல்") || q.contains("பூச்சி") || q.contains("pest") -> {
                if (lang == AppLanguage.TAMIL) {
                    "🌿 பயிர் பாதுகாப்பு & நோய் மேலாண்மை வழிகாட்டுதல்:\n• நெல் இலைக்கருகல் நோய்: ட்ரைசைக்ளசோல் 75% WP @ 0.6 கிராம்/லிட்டர் அல்லது 10% மாட்டு சிறுநீர் + பெருங்காயம் கரைசல் தெளிக்கவும்.\n• சின்ன வெங்காயம் & மிளகாய் இலைசுருட்டு: ஐந்திலை கரைசல் அல்லது டயாபென்தியூரான் 50% WP @ 1.25 கிராம்/லிட்டர்.\n• இயற்கை பூச்சிவிரட்டி: 10,000 ppm வேப்பெண்ணெய் 3 மிலி/லிட்டர் நீரில் ஒட்டும் திரவம் சேர்த்து தெளிக்கவும்.\n\nநோய் தாக்கிய இலையை நமது 'பயிர் மருத்துவர்' ஸ்கேனரில் படம் பிடித்தால் உடனடி துல்லிய தீர்வை பெறலாம்!"
                } else {
                    "🌿 Crop Protection & Pest Advisory:\n• Rice Leaf Blast: Spray Tricyclazole 75% WP @ 0.6g/L water or apply organic 10% cow urine + asafoetida extract.\n• Chilli Leaf Curl & Thrips: Spray Diafenthiuron 50% WP @ 1.25g/L or 5-leaf herbal organic decoction.\n• Organic Pest Repellent: Cold-pressed Neem oil 10,000 ppm @ 3ml/L water.\n\nUse our 'Crop Doctor Scanner' to scan a diseased leaf for instant AI diagnosis and remedies!"
                }
            }
            q.contains("உரம்") || q.contains("fertilizer") || q.contains("urea") || q.contains("யூரியா") || q.contains("பஞ்சகாவ்யா") -> {
                if (lang == AppLanguage.TAMIL) {
                    "🧪 உரம் & இயற்கை இடுபொருட்கள் ஆலோசனை:\n• யூரியா (45 கிலோ மூட்டை) அரசு மானிய விலை ₹266. தூர் கட்டும் பருவத்தில் மட்டும் இடவும்.\n• டி.ஏ.பி (DAP 50 கிலோ) ₹1,350. அடி உரமாக இட வேண்டும்.\n• இயற்கை பஞ்சகாவ்யா: 3% கரைசலாக (1 லிட்டர் நீரில் 30 மிலி) பயிர்களுக்கு தெளித்தால் நோய் எதிர்ப்பு சக்தியும் அதிக விளைச்சலும் கிடைக்கும்.\n• அருகில் உள்ள PACCS தொடக்க வேளாண் கூட்டுறவு சங்கங்களின் இருப்பு நிலவரத்தை 'உரக்கடைகள்' பக்கத்தில் ஒப்பிட்டு பார்க்கலாம்!"
                } else {
                    "🧪 Fertilizer & Bio-Input Advisory:\n• Neem-coated Urea (45 kg) Govt subsidized MRP: ₹266.\n• DAP 18:46:00 (50 kg): ₹1,350 as basal fertilizer.\n• Panchagavya: 3% foliar spray (30 ml/L water) acts as an organic growth booster and pest repellent.\n• Compare nearby PACCS cooperative and private agro dealers under the 'Agri Stores' tab!"
                }
            }
            else -> {
                if (lang == AppLanguage.TAMIL) {
                    "விவசாய நண்பரே, உங்கள் கேள்விக்கு மகிழ்ச்சியுடன் உதவ தயாராக உள்ளேன். உழவன் X செயலியில் நீங்கள்:\n1. 'பயிர் பரிந்துரை' மூலம் உங்கள் ஊர், மண் மற்றும் தற்போதைய சந்தை விலைக்கு உகந்த பயிரை கண்டறியலாம்.\n2. 'உரக்கடைகள்' மூலம் தமிழ்நாடு முழுவதிலும் உள்ள கடைகளின் உர விலைகளை ஒப்பிடலாம்.\n3. 'பயிர் மருத்துவர்' மூலம் நோய் தாக்கிய இலைகளை ஸ்கேன் செய்து உடனடி இயற்கை/இரசாயன தீர்வுகளை பெறலாம்.\n4. 'அரசு திட்டங்கள்' மூலம் 2026 மானியங்கள் மற்றும் பயிர் கடன்களுக்கு விண்ணப்பிக்கலாம்."
                } else {
                    "Dear Farmer, I am here to help you maximize your agricultural profits. With Uzhav X you can:\n1. Get AI Crop Recommendations tailored to your district, soil type, and mandi prices.\n2. Compare fertilizer prices (chemical & organic) across all Tamil Nadu agro centers.\n3. Scan plant leaves for instant disease diagnosis and organic/chemical remedies.\n4. Explore comprehensive 2026 government subsidies (Maniyam) and KCC loans."
                }
            }
        }
    }
}
