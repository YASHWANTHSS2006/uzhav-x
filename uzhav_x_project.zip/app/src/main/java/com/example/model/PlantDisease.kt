package com.example.model

data class PlantDiseaseDiagnosis(
    val id: String,
    val cropName: String,
    val tamilCropName: String,
    val diseaseName: String,
    val tamilDiseaseName: String,
    val scientificName: String,
    val confidencePercent: Int,
    val severityLevel: String, // Mild, Moderate, Severe
    val symptomsEnglish: List<String>,
    val symptomsTamil: List<String>,
    val organicRemedies: List<String>,
    val chemicalTreatments: List<String>,
    val preventiveCare: List<String>,
    val tnauexpertNote: String
)
