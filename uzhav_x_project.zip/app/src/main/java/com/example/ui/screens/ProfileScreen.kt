package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.components.LanguageSelectionCard
import com.example.viewmodel.UzhavViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    viewModel: UzhavViewModel,
    state: com.example.viewmodel.UzhavUiState,
    modifier: Modifier = Modifier
) {
    val lang = state.language
    val profile = state.farmerProfile
    val primaryColor = MaterialTheme.colorScheme.primary

    var name by remember { mutableStateOf(profile.name) }
    var contact by remember { mutableStateOf(profile.contact) }
    var district by remember { mutableStateOf(profile.district) }
    var taluka by remember { mutableStateOf(profile.taluka) }
    var village by remember { mutableStateOf(profile.village) }
    var landSize by remember { mutableStateOf(profile.landSizeAcres.toString()) }
    var soilType by remember { mutableStateOf(profile.soilType) }
    var waterSource by remember { mutableStateOf(profile.waterSource) }

    var districtExpanded by remember { mutableStateOf(false) }
    var soilExpanded by remember { mutableStateOf(false) }
    var savedNotice by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("profile_registration_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Title
        item {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AccountCircle,
                        contentDescription = "Profile",
                        tint = primaryColor,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (lang == AppLanguage.TAMIL) "விவசாயி பதிவு & பண்ணை விவரம்" else "Farmer Registration & Profile",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
                Text(
                    text = if (lang == AppLanguage.TAMIL) "உங்கள் ஊர் மற்றும் மண் வகையை பதிவு செய்வதன் மூலம் துல்லியமான பயிர் பரிந்துரைகளையும் மானிய தகவல்களையும் பெறலாம்."
                    else "Keep your farm details updated to receive localized mandi price alerts and tailored crop advisories.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.outline
                )
            }
        }

        // Language Switcher Component
        item {
            LanguageSelectionCard(
                currentLanguage = lang,
                onLanguageSelected = { newLanguage ->
                    viewModel.setLanguage(newLanguage)
                }
            )
        }

        // Google Authentication Status & Login Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (profile.isRegistered) Color(0xFFE8F5E9) else Color(0xFFF1F8E9)
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (profile.isRegistered) Icons.Default.Verified else Icons.Default.Lock,
                                contentDescription = null,
                                tint = if (profile.isRegistered) Color(0xFF2E7D32) else Color(0xFF388E3C),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (profile.isRegistered)
                                    (if (lang == AppLanguage.TAMIL) "Google கணக்கு இணைக்கப்பட்டது" else "Google Account Linked")
                                else
                                    (if (lang == AppLanguage.TAMIL) "பாதுகாப்பான உள்நுழைவு" else "Secure Login"),
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1B5E20)
                            )
                        }
                        Text(
                            text = if (profile.isRegistered)
                                profile.contact.ifBlank { profile.name }
                            else
                                (if (lang == AppLanguage.TAMIL) "மேகக்கணியில் தரவுகளை சேமிக்க உள்நுழைக" else "Sign in with Google to sync farm records"),
                            fontSize = 12.sp,
                            color = Color(0xFF2E7D32)
                        )
                    }

                    Button(
                        onClick = { viewModel.navigateTo(com.example.viewmodel.UzhavScreen.LOGIN) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = if (profile.isRegistered)
                                (if (lang == AppLanguage.TAMIL) "மாற்று" else "Manage")
                            else
                                (if (lang == AppLanguage.TAMIL) "உள்நுழை" else "Sign In"),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Form Fields
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // Full Name
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text(if (lang == AppLanguage.TAMIL) "விவசாயி பெயர்" else "Farmer Full Name") },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Phone or Email ID
                    OutlinedTextField(
                        value = contact,
                        onValueChange = { contact = it },
                        label = { Text(if (lang == AppLanguage.TAMIL) "தொலைபேசி எண் / மின்னஞ்சல்" else "Mobile Number / Email ID") },
                        leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth()
                    )

                    // State (Tamil Nadu)
                    OutlinedTextField(
                        value = "Tamil Nadu (தமிழ்நாடு)",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text(if (lang == AppLanguage.TAMIL) "மாநிலம்" else "State") },
                        leadingIcon = { Icon(Icons.Default.LocationCity, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth()
                    )

                    // District Dropdown
                    ExposedDropdownMenuBox(
                        expanded = districtExpanded,
                        onExpandedChange = { districtExpanded = it },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = district,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(if (lang == AppLanguage.TAMIL) "மாவட்டம்" else "District") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = districtExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = districtExpanded,
                            onDismissRequest = { districtExpanded = false }
                        ) {
                            TAMIL_NADU_DISTRICTS.forEach { dist ->
                                DropdownMenuItem(
                                    text = { Text(dist) },
                                    onClick = {
                                        district = dist
                                        districtExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Taluka / Region & Village
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = taluka,
                            onValueChange = { taluka = it },
                            label = { Text(if (lang == AppLanguage.TAMIL) "வட்டம் / தாலுகா" else "Taluk / Region") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = village,
                            onValueChange = { village = it },
                            label = { Text(if (lang == AppLanguage.TAMIL) "கிராமம்" else "Village") },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Land Size
                    OutlinedTextField(
                        value = landSize,
                        onValueChange = { landSize = it },
                        label = { Text(if (lang == AppLanguage.TAMIL) "நில அளவு (ஏக்கரில்)" else "Land Size (Acres)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Soil Type
                    ExposedDropdownMenuBox(
                        expanded = soilExpanded,
                        onExpandedChange = { soilExpanded = it },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = soilType,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(if (lang == AppLanguage.TAMIL) "மண் வகை" else "Soil Type") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = soilExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = soilExpanded,
                            onDismissRequest = { soilExpanded = false }
                        ) {
                            SOIL_TYPES.forEach { soil ->
                                DropdownMenuItem(
                                    text = { Text(soil) },
                                    onClick = {
                                        soilType = soil
                                        soilExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Role Selection (Farmer vs Admin)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (lang == AppLanguage.TAMIL) "செயலி பயன்பாட்டு உரிமை" else "App Role Access",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = state.currentRole.getDisplayName(lang),
                                style = MaterialTheme.typography.bodySmall,
                                color = primaryColor
                            )
                        }
                        Button(
                            onClick = { viewModel.toggleUserRole() },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(if (state.currentRole == UserRole.FARMER) "Switch to Admin" else "Switch to Farmer")
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Save Button
                    Button(
                        onClick = {
                            val acres = landSize.toDoubleOrNull() ?: profile.landSizeAcres
                            val updated = profile.copy(
                                name = name,
                                contact = contact,
                                district = district,
                                taluka = taluka,
                                village = village,
                                landSizeAcres = acres,
                                soilType = soilType,
                                waterSource = waterSource
                            )
                            viewModel.updateProfile(updated)
                            savedNotice = true
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = "Save")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (lang == AppLanguage.TAMIL) "சுயவிவரத்தை சேமிக்க" else "Save Farm Profile",
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (savedNotice) {
                        Text(
                            text = if (lang == AppLanguage.TAMIL) "✔ சுயவிவரம் வெற்றிகரமாக சேமிக்கப்பட்டது!" else "✔ Profile saved successfully!",
                            color = primaryColor,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )
                    }
                }
            }
        }

        // Tech Stack & Full Stack Architecture Card
        item {
            var showTechStackDialog by remember { mutableStateOf(false) }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Layers, contentDescription = "Stack", tint = primaryColor)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (lang == AppLanguage.TAMIL) "உழவன் X: தொழில்நுட்ப அடுக்கு (Tech Stack)" else "Uzhav X: Full Tech Stack Architecture",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Text(
                        text = if (lang == AppLanguage.TAMIL) "Kotlin, Jetpack Compose M3, Room SQLite, AI கணிப்பான், மற்றும் இரட்டை பயனர்/நிர்வாகி அணுகல் கட்டமைப்பு."
                        else "Modern Android architecture powered by Kotlin, Jetpack Compose M3, Room DB, Gemini AI, and dual Role-Based Access Control.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline
                    )

                    OutlinedButton(
                        onClick = { showTechStackDialog = true },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (lang == AppLanguage.TAMIL) "முழு தொழில்நுட்ப விவரங்களை காண்க" else "View Full Stack Architecture")
                    }
                }
            }

            if (showTechStackDialog) {
                AlertDialog(
                    onDismissRequest = { showTechStackDialog = false },
                    title = {
                        Text(
                            text = "Uzhav X - Full Stack Architecture",
                            fontWeight = FontWeight.Bold
                        )
                    },
                    text = {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            item {
                                Surface(shape = RoundedCornerShape(8.dp), color = Color(0xFFE8F5E9)) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("1. Presentation Layer (Mobile UI)", fontWeight = FontWeight.Bold, color = Color(0xFF1B5E20))
                                        Text("• Jetpack Compose Material 3 with adaptive layouts\n• Canvas graphics for 7-day Mandi line charts & TN agro-hub maps\n• Dynamic English & Tamil (தமிழ்) runtime localization", fontSize = 12.sp)
                                    }
                                }
                            }
                            item {
                                Surface(shape = RoundedCornerShape(8.dp), color = Color(0xFFE3F2FD)) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("2. Business Logic & State", fontWeight = FontWeight.Bold, color = Color(0xFF1565C0))
                                        Text("• MVVM with StateFlow & collectAsStateWithLifecycle\n• Reactive unidirectional data flow\n• Coroutine dispatchers for asynchronous background calculations", fontSize = 12.sp)
                                    }
                                }
                            }
                            item {
                                Surface(shape = RoundedCornerShape(8.dp), color = Color(0xFFFFF3E0)) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("3. AI Intelligence & Agronomy Engine", fontWeight = FontWeight.Bold, color = Color(0xFFE65100))
                                        Text("• Gemini AI API with Tamil agriculture system prompt\n• Computer Vision Leaf Disease Scanner\n• TNAU district-soil-season profit optimization algorithm", fontSize = 12.sp)
                                    }
                                }
                            }
                            item {
                                Surface(shape = RoundedCornerShape(8.dp), color = Color(0xFFF3E5F5)) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("4. Local & Cloud Data Persistence", fontWeight = FontWeight.Bold, color = Color(0xFF7B1FA2))
                                        Text("• Room SQLite Database with DAO for offline caching\n• Dual Role Access Control (Farmer User vs Store Admin)\n• Retrofit 2 + Moshi + OkHttp network stack", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = {
                        Button(onClick = { showTechStackDialog = false }) {
                            Text("Close")
                        }
                    }
                )
            }
        }
    }
}
